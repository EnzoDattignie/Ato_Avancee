#include <stdio.h>

int main (int argc, char *argv[])
{
  printf("HELLO WORLD on cluster IO!\n");
}

